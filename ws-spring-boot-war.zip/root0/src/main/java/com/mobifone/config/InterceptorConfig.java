package ${IJ_BASE_PACKAGE}.config;

import ${IJ_BASE_PACKAGE}.interceptor.BaseInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

@Configuration
public class InterceptorConfig extends WebMvcConfigurerAdapter {

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new BaseInterceptor()).addPathPatterns("/*");
        //registry.addInterceptor(new BaseInterceptor()).addPathPatterns("/*").excludePathPatterns("/admin/oldLogin");
    }

}
